import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:flutter/widgets.dart';
import 'package:sleek_circular_slider/sleek_circular_slider.dart';

double temperatureData = 25; // value for temperature

Color subheadFontColor = const Color.fromARGB(255, 112, 112, 112);

class Temperature extends StatelessWidget {
  final String title;
  const Temperature({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            // Text("data of temperature here"),
            Center(
              child: Text(temperatureData.toString(),
                  // textScaleFactor: 2,
                  style: TextStyle(color: subheadFontColor, fontSize: 100)),
            ),

            Center(
              child: Text(
                "Temperature",
                textScaleFactor: 2,
                style: TextStyle(
                  color: subheadFontColor,
                  // fontStyle:
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
