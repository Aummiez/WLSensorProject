
import 'package:flutter/material.dart';


double pm25Data = 16; //value for PM2.5

Color subheadFontColor = const Color.fromARGB(255, 112, 112, 112);

class PM25 extends StatelessWidget {
  final String title;
  const PM25({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            // Text("data of temperature here"),
            Center(
              child: Text(pm25Data.toString(),
                  // textScaleFactor: 2,
                  style: TextStyle(color: subheadFontColor, fontSize: 100)),
            ),

            Center(
              child: Text(
                "PM 2.5",
                textScaleFactor: 2,
                style: TextStyle(
                  color: subheadFontColor,
                  // fontStyle:
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
