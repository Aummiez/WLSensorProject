import 'package:flutter/material.dart';

class AllSensor extends StatelessWidget {
  final String title;
  const AllSensor({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text("data of sensors here"),
          ],
        ),
      ),
    );
  }
}
