import 'package:flutter/material.dart';

String username = "Atchaye Apattitetena";
String location = "Hyuga House, Konoha";
String tel_Numb = "081-2345678";
String email = "atchaye.apa@student.mahidol.ac.th";

double pm25Data = 16; //value for PM2.5
Color headingFontColor = const Color.fromARGB(255, 0, 0, 0);

class Profile extends StatelessWidget {
  // const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // debugShowMaterialGrid: false,
      // Application name
      body: Center(
        child: Container(
          margin: const EdgeInsets.only(top: 25),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundColor: Colors.grey,
                radius: 90,
              ),
              Text(
                "Edit Picture",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.blueAccent,
                  fontSize: 11,
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 25),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text(
                      username,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: headingFontColor,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      location,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: headingFontColor,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      tel_Numb,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: headingFontColor,
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      email,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: headingFontColor,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
