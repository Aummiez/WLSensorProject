import 'package:flutter/material.dart';

import '../views/humidity.dart';
import '../views/temperature.dart';

import '../views/allsensor.dart';
import '../views/pm25.dart';

String username = "Atchaye Apattitetena";

Color headingFontColor = const Color.fromARGB(255, 0, 0, 0);
Color subheadFontColor = const Color.fromARGB(255, 112, 112, 112);
Color iconColor = const Color.fromARGB(255, 24, 22, 58);
Color navyBlue = Color.fromARGB(255, 25, 23, 97); // For icons,..

class Home extends StatelessWidget {
  // const MyApp({super.key});

  final Function(int) fn;

  static const String _title = 'Head of Home';

  const Home(this.fn, {super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      // Application name
      title: _title,
      // theme: ThemeData(),
      home: SetupHeading(fn),
    );
  }
}

class SetupHeading extends StatelessWidget {
  // const MyStatelessWidget({super.key});
  //

  final Function(int) fn;

  const SetupHeading(
    this.fn, {
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      initialIndex: 1,
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          leading: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Colors.white, // background
              // onPrimary: Colors.grey, // foreground
            ),
            onPressed: () {
              // Navigator.push(
              //     context, MaterialPageRoute(builder: (context) => Profile()));
              fn(2);
            },
            child: const Icon(
              Icons.person_rounded,
              color: Colors.grey,
            ),
          ),
          title: Container(
            margin: const EdgeInsets.only(top: 2),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Welcome Home,",
                  selectionColor: subheadFontColor,
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      color: subheadFontColor, height: 2, fontSize: 10),
                ),
                TextButton(
                  onPressed: () {
                    // Navigator.push(context,
                    //     MaterialPageRoute(builder: (context) => Profile()));
                    fn(2);
                  },
                  child: Text(
                    username,
                    selectionColor: headingFontColor,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        color: headingFontColor, height: 1, fontSize: 18),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            // main
            Container(
              margin: EdgeInsets.all(5.0),
              child: Row(
                children: [
                  const Icon(
                    Icons.notifications,
                    color: Color.fromARGB(255, 25, 23, 97),
                  ),
                  const Icon(
                    Icons.add_box,
                    color: Color.fromARGB(255, 25, 23, 97),
                  ),
                ],
              ),
            )
          ],
          bottom: const TabBar(
            labelColor: Colors.black,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.black,
            tabs: <Widget>[
              Tab(
                text: "All Sensor",
              ),
              Tab(
                text: "PM 2.5",
              ),
              Tab(
                text: "Temperature",
              ),
              Tab(
                text: "Humidity",
              ),

              // selectedItemColor: Colors.black,
            ],
          ),
        ),
        body: const TabBarView(
          children: <Widget>[
            Center(
              child: AllSensor(title: 'Tab one'),
            ),
            Center(
              child: PM25(title: 'Tab two'),
            ),
            Center(
              child: Temperature(title: 'Tab three'),
            ),
            Center(
              child: Humidity(title: 'Tab four'),
            ),
          ],
        ),
      ),
    );
  }
}
