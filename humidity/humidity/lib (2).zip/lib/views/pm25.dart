import 'dart:js_util';

import 'package:flutter/material.dart';

double pm25Data = 120; //value for PM2.5

Color pm25Color(double value) {
  // for PM2.5 (micrograms/m^2)
  if (value <= 12.0) {
    // Good
    return Colors.blueAccent;
  } else if (value <= 35.4) {
    // Moderate
    return Colors.green;
  } else if (value <= 55.4) {
    // Moderate
    return Color.fromARGB(255, 235, 216, 41);
  } else if (value <= 150.4) {
    // Moderate
    return Colors.red;
  } else if (value <= 250.4) {
    // Moderate
    return Color.fromARGB(255, 114, 21, 131);
  } else {
    return Color.fromARGB(255, 67, 9, 53);
  }
  // Hazardous
}

Color subheadFontColor = const Color.fromARGB(255, 112, 112, 112);

class PM25 extends StatelessWidget {
  final String title;
  const PM25({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        heightFactor: 450,
        widthFactor: 450,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              // color: Colors.transparent,
              height: 250,
              width: 250,
              decoration: BoxDecoration(
                color: pm25Color(pm25Data),
                borderRadius: BorderRadius.circular(50),
              ),
              alignment: Alignment.center,
              child: Text(
                pm25Data.toString(),
                // textScaleFactor: 2,
                style: TextStyle(color: Colors.white, fontSize: 100),
              ),
            ),
            Center(
              child: Text(
                "PM 2.5",
                textScaleFactor: 2,
                style: TextStyle(
                  color: subheadFontColor,
                  // fontStyle:
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
