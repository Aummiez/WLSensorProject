package com.example.humidity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
