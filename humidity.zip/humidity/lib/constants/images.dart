
class Images {
  Images._();
  static const String cloudyAnim = 'assets/anims/cloudy.json';
  static const String cloudyMain = 'assets/anims/cloudy_main.json';
}
